﻿public class CoordenadasDetalhadas
{
    public double? Latitude { get; set; }
    public double? Longitude { get; set; }
    public string? Estado { get; set; }
    public string? Cidade { get; set; }
    public string? Bairro { get; set; }
}
